import pygame
import random
pygame.init()  # initalizes Pygame
pygame.display.set_caption("soullesss flight")  # sets the window title
screen = pygame.display.set_mode((500, 500))  # creates game screen 
clock = pygame.time.Clock()# start game clock

#game varialbles---------------------------------------------
doExit = False #this variable controls our game loop
playerX = 200 #player x position
playerY = 200 #player y position
isOnGround = False 
Vx = 0 #player left/right speed
Vy = 0 #player up/down speed
xDirection = 1 #(1 is left, 2 is right)
yDirection = 1 #(1 is down, 2 is up)
rightCollision = False

#------------posibol fixs----------------------
#offset = 0

Map = [[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
       [0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,1,0],
       [0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,1,0,1,1],
       [1,0,0,0,0,0,1,0,1,1,0,1,0,0,1,0,1,0,1,1],
       [1,0,1,0,1,0,1,1,1,1,0,1,0,0,1,0,1,1,1,1],
       [1,1,1,0,1,0,1,1,1,1,1,1,0,1,1,0,1,1,1,1],
       [1,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1],
       [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]]

#game loop#######################################
while not doExit:
    clock.tick(60)
#physics section-----------------------------
    #lets you quit the game from the gamescreen
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            doExit = True
   
    # input/output section
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        Vx = -2
    if keys[pygame.K_RIGHT] and rightCollision == False:
        Vx = 2
    if keys[pygame.K_SPACE] or keys[pygame.K_UP]:
        if isOnGround == True: #comment this to ensable double jumping
            Vy = -5
            isOnGround = False


    #trampoline bounce
    #if playerX > 20 or playerX<90 and playerY > 20:
    #  Vy = -10
    #if playerY < 0 or playerY+20 > 500:
     # Vy = -10
    #set directions

    if Vy >= 0:
      yDirection = 1
    else:
      yDirection = 2

    #check if you're on the ground
    if playerY > 500 - 20: #check if your feet are on the ground
        isOnGround = True
        playerY = 500 - 20
        Vx = 0 #sets up friction
    #else:
     #   isOnGround = False
    if playerY<0:#ceiling collision
      playerY = 0

    #FEETiesS collision down
    #print("player is at ", playerX, " , ", playerY)
    if Map[int((playerY+20)/25)][int(playerX/25)]==1 and yDirection == 1:
        print("feets collision!")
        Vy = 0
        isOnGround = True
    else:
        print("NOFEETS")
        isOnGround = False
        #Vx *=-1 do this for left/right collision

    #right collision
    if Map[int(playerY/25)][int((playerX+20)/25)]==1 and xDirection == 1:
        print("right collision!")
        rightCollision = True
    else:
      rightCollision = False
        #Vy = 0
        #Vx *=-1 #do this for left/right collision
        #isOnGround = True

    #if Map[int(playerY/25)][int((playerX)/25)]==1:

      #if xDirection == 1:
        #print("feets collision!")
        #Vy = 0
        #Vx *=-1 #do this for left/right collision
        #isOnGround = True




    #GRAVITY
    if isOnGround == False:
        print("applying gravity")
        Vy+=.2 #GRAVITY if not on ground, fall downwards
    
    
    #friction 
    Vx *= .8 #smaller numbers mean MORE friction


#update player position
    playerX += Vx
    playerY += Vy
    
        
#render section-------------------------------
    screen.fill((0, 0, 0)) #clear screen between loops
    pygame.draw.rect(screen, (255, 50, 50), (playerX, playerY, 20, 20)) #draw player
    


    for i in range (20):
      for j in range (20):
        pygame.draw.rect(screen,(100,100,0),(i*25, j*25, 25, 25), 1)
        if Map[j][i] == 1:
            pygame.draw.rect(screen,(0,100,0),(i*25, j*25, 25, 25))
            
      


    pygame.display.flip() #draws all the stuff above the screen    
    
#####################################end game loop
pygame.quit()

